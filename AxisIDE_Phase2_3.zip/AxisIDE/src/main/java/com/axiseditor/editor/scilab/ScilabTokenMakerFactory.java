package com.axiseditor.editor.scilab;

import org.fife.ui.rsyntaxtextarea.AbstractTokenMakerFactory;
import org.fife.ui.rsyntaxtextarea.TokenMaker;

/**
 * ScilabTokenMakerFactory — registers our custom ScilabTokenMaker with
 * RSyntaxTextArea so we can set:
 *
 *   textArea.setSyntaxEditingStyle("text/scilab");
 *
 * Registration is done once at startup via:
 *   AbstractTokenMakerFactory.setDefaultInstance(new ScilabTokenMakerFactory());
 */
public class ScilabTokenMakerFactory extends AbstractTokenMakerFactory {

    public static final String SYNTAX_STYLE_SCILAB = "text/scilab";

    @Override
    protected void initTokenMakerMap() {
        putMapping(SYNTAX_STYLE_SCILAB, ScilabTokenMaker.class.getName());
    }

    @Override
    public TokenMaker getTokenMaker(String key) {
        if (SYNTAX_STYLE_SCILAB.equals(key)) {
            return new ScilabTokenMaker();
        }
        // Fall back to the default factory for all other languages
        return super.getTokenMaker(key);
    }
}
