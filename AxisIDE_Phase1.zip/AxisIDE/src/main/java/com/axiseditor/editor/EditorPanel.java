package com.axiseditor.editor;

import com.axiseditor.utils.UIConstants;
import org.fife.ui.rsyntaxtextarea.RSyntaxTextArea;
import org.fife.ui.rsyntaxtextarea.SyntaxConstants;
import org.fife.ui.rtextarea.RTextScrollPane;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/**
 * EditorPanel — hosts the RSyntaxTextArea with scroll pane.
 *
 * Phase 1 responsibilities:
 *   • Display text content from opened files
 *   • Report unsaved-change state via a listener
 *
 * Phase 2 will add: syntax highlighting config, bracket matching, auto-indent.
 */
public class EditorPanel extends JPanel {

    private final RSyntaxTextArea textArea;
    private final RTextScrollPane scrollPane;

    /** Fired whenever the document changes (used by FileManager). */
    private Runnable onModifiedCallback;

    public EditorPanel() {
        setLayout(new BorderLayout());

        textArea = buildTextArea();
        scrollPane = new RTextScrollPane(textArea);
        scrollPane.setLineNumbersEnabled(true);   // line numbers on by default

        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY),
                "Editor",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                UIConstants.LABEL_FONT
        );
        setBorder(border);
        add(scrollPane, BorderLayout.CENTER);

        // Notify FileManager whenever the user types
        textArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e)  { notifyModified(); }
            @Override public void removeUpdate(DocumentEvent e)  { notifyModified(); }
            @Override public void changedUpdate(DocumentEvent e) { notifyModified(); }
        });
    }

    // ── Builder ─────────────────────────────────────────────────────────────

    private RSyntaxTextArea buildTextArea() {
        RSyntaxTextArea ta = new RSyntaxTextArea();

        /*
         * Phase 1: plain text mode.
         * Phase 2 will switch to a custom Scilab token maker:
         *   ta.setSyntaxEditingStyle("text/scilab");
         */
        ta.setSyntaxEditingStyle(SyntaxConstants.SYNTAX_STYLE_NONE);

        ta.setFont(UIConstants.EDITOR_FONT);
        ta.setTabSize(4);
        ta.setAutoIndentEnabled(true);      // basic auto-indent (Phase 2 enhances)
        ta.setAntiAliasingEnabled(true);
        ta.setCodeFoldingEnabled(false);    // Phase 2 feature
        ta.setHighlightCurrentLine(true);
        ta.setCurrentLineHighlightColor(new Color(232, 242, 254));  // subtle blue tint

        // Bracket matching — enabled here, full config in Phase 2
        ta.setBracketMatchingEnabled(true);
        ta.setAnimateBracketMatching(true);

        // Comfortable margins
        ta.setMargin(new Insets(4, 6, 4, 6));

        return ta;
    }

    // ── Public API ──────────────────────────────────────────────────────────

    /** Replace the entire editor content (called on file open). */
    public void setText(String content) {
        textArea.setText(content);
        textArea.setCaretPosition(0);       // scroll back to top
        textArea.discardAllEdits();         // clear undo history for new file
    }

    /** Get the current editor content. */
    public String getText() {
        return textArea.getText();
    }

    /** Check whether the text area is empty. */
    public boolean isEmpty() {
        return textArea.getText().trim().isEmpty();
    }

    /**
     * Register a callback fired on every keystroke / document change.
     * FileManager uses this to track the "modified" state.
     */
    public void setOnModifiedCallback(Runnable callback) {
        this.onModifiedCallback = callback;
    }

    /** Expose the underlying RSyntaxTextArea for Phase 2/4 configuration. */
    public RSyntaxTextArea getTextArea() {
        return textArea;
    }

    // ── Internals ───────────────────────────────────────────────────────────

    private void notifyModified() {
        if (onModifiedCallback != null) {
            onModifiedCallback.run();
        }
    }
}
