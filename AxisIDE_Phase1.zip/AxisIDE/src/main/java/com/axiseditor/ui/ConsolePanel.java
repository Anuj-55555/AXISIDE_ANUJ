package com.axiseditor.ui;

import com.axiseditor.utils.UIConstants;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

/**
 * ConsolePanel — read-only output area shown to the right of the editor.
 *
 * Phase 1: displays plain text messages (file open/save feedback).
 * Phase 3: will display Scilab execution output and errors.
 */
public class ConsolePanel extends JPanel {

    private final JTextArea outputArea;

    public ConsolePanel() {
        setLayout(new BorderLayout());
        setMinimumSize(new Dimension(200, 0));

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(UIConstants.CONSOLE_FONT);
        outputArea.setBackground(UIConstants.CONSOLE_BG);
        outputArea.setForeground(UIConstants.CONSOLE_FG);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        outputArea.setMargin(new Insets(6, 8, 6, 8));

        JScrollPane scrollPane = new JScrollPane(outputArea);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.GRAY, 1),
                "Console Output",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                UIConstants.LABEL_FONT
        );
        setBorder(border);
        add(scrollPane, BorderLayout.CENTER);

        // Clear button
        JButton btnClear = new JButton("Clear");
        btnClear.setFont(UIConstants.BUTTON_FONT);
        btnClear.setFocusPainted(false);
        btnClear.addActionListener(e -> clear());
        JPanel bottomBar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 4, 2));
        bottomBar.add(btnClear);
        add(bottomBar, BorderLayout.SOUTH);

        appendMessage("Axis IDE — Console ready.\n");
    }

    // ── Public API ──────────────────────────────────────────────────────────

    /** Append a plain informational message. */
    public void appendMessage(String text) {
        outputArea.append(text);
        scrollToBottom();
    }

    /** Append an error message (same colour for now; Phase 3 adds red). */
    public void appendError(String text) {
        outputArea.append("[ERROR] " + text);
        scrollToBottom();
    }

    /** Clear the console. */
    public void clear() {
        outputArea.setText("");
    }

    // ── Internals ───────────────────────────────────────────────────────────

    private void scrollToBottom() {
        SwingUtilities.invokeLater(() ->
                outputArea.setCaretPosition(outputArea.getDocument().getLength()));
    }
}
