package com.axiseditor.ui;

import com.axiseditor.editor.EditorPanel;
import com.axiseditor.filemanager.FileManager;
import com.axiseditor.utils.UIConstants;

import javax.swing.*;
import java.awt.*;

/**
 * ToolbarPanel — horizontal strip of action buttons.
 *
 * Phase 1 buttons: New · Open · Save · Save As
 * (Run button will be wired in Phase 3)
 */
public class ToolbarPanel extends JPanel {

    private final FileManager   fileManager;
    private final EditorPanel   editorPanel;
    private final ConsolePanel  consolePanel;

    // Buttons declared as fields so other phases can enable/disable them
    private JButton btnNew;
    private JButton btnOpen;
    private JButton btnSave;
    private JButton btnSaveAs;
    private JButton btnRun;       // placeholder — enabled in Phase 3

    public ToolbarPanel(FileManager fileManager,
                        EditorPanel editorPanel,
                        ConsolePanel consolePanel) {
        this.fileManager  = fileManager;
        this.editorPanel  = editorPanel;
        this.consolePanel = consolePanel;
        initUI();
    }

    private void initUI() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 4, 4));
        setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
        setBackground(UIConstants.TOOLBAR_BG);

        btnNew    = createButton("New",    "Create a new Scilab script",    e -> fileManager.newFile());
        btnOpen   = createButton("Open",   "Open an existing Scilab file",  e -> fileManager.openFile());
        btnSave   = createButton("Save",   "Save the current file",         e -> fileManager.saveFile());
        btnSaveAs = createButton("Save As","Save the file under a new name",e -> fileManager.saveFileAs());

        // Phase 3 placeholder — greyed out for now
        add(new JSeparator(JSeparator.VERTICAL));
        btnRun = createButton("▶  Run", "Run the current script (Phase 3)", null);
        btnRun.setEnabled(false);
        btnRun.setForeground(Color.GRAY);

        add(btnNew);
        add(btnOpen);
        add(btnSave);
        add(btnSaveAs);
        add(new JSeparator(JSeparator.VERTICAL));
        add(btnRun);
    }

    /** Factory for uniform button styling. */
    private JButton createButton(String text, String tooltip,
                                 java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setToolTipText(tooltip);
        btn.setFocusPainted(false);
        btn.setFont(UIConstants.BUTTON_FONT);
        if (action != null) btn.addActionListener(action);
        return btn;
    }

    // ── Phase 3 hook ────────────────────────────────────────────────────────
    /** Called by Phase 3 to activate the Run button. */
    public void enableRunButton(java.awt.event.ActionListener runAction) {
        btnRun.setEnabled(true);
        btnRun.setForeground(new Color(0, 128, 0));
        btnRun.addActionListener(runAction);
    }
}
