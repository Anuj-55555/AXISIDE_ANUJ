package com.axiseditor.ui;

import com.axiseditor.editor.EditorPanel;
import com.axiseditor.filemanager.FileManager;
import com.axiseditor.utils.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * MainWindow — the root JFrame of the Axis IDE.
 *
 * Layout:
 *   ┌─────────────────────────────────┐
 *   │  Toolbar (JToolBar)             │
 *   ├─────────────────────┬───────────┤
 *   │  Editor Panel       │  Console  │
 *   │  (RSyntaxTextArea)  │  Panel    │
 *   ├─────────────────────┴───────────┤
 *   │  Status Bar (JLabel)            │
 *   └─────────────────────────────────┘
 */
public class MainWindow extends JFrame {

    private EditorPanel editorPanel;
    private ConsolePanel consolePanel;
    private ToolbarPanel toolbarPanel;
    private StatusBar statusBar;
    private FileManager fileManager;

    public MainWindow() {
        super(UIConstants.APP_TITLE);
        initComponents();
        setupLayout();
        setupWindowBehaviour();
    }

    /** Instantiate all sub-components. */
    private void initComponents() {
        // FileManager is shared — it talks to the editor and status bar
        fileManager    = new FileManager(this);
        editorPanel    = new EditorPanel();
        consolePanel   = new ConsolePanel();
        statusBar      = new StatusBar();
        toolbarPanel   = new ToolbarPanel(fileManager, editorPanel, consolePanel);

        // Wire up cross-component communication
        fileManager.setEditorPanel(editorPanel);
        fileManager.setStatusBar(statusBar);
        fileManager.setConsolePanel(consolePanel);
    }

    /** Arrange panels inside the frame. */
    private void setupLayout() {
        setLayout(new BorderLayout());

        // Toolbar at the top
        add(toolbarPanel, BorderLayout.NORTH);

        // Editor (left/centre) and Console (right) split pane
        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT,
                editorPanel,
                consolePanel
        );
        splitPane.setResizeWeight(0.75);          // editor gets 75% of width
        splitPane.setDividerSize(5);
        splitPane.setContinuousLayout(true);
        add(splitPane, BorderLayout.CENTER);

        // Status bar at the bottom
        add(statusBar, BorderLayout.SOUTH);

        // Frame sizing
        setSize(UIConstants.DEFAULT_WIDTH, UIConstants.DEFAULT_HEIGHT);
        setMinimumSize(new Dimension(800, 500));
        setLocationRelativeTo(null);              // center on screen
    }

    /** Handle close button — prompt to save unsaved changes. */
    private void setupWindowBehaviour() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                fileManager.promptSaveBeforeAction("Exit", MainWindow.this::dispose);
            }
        });
    }

    // ── Accessors for child panels ─────────────────────────────────────────

    public EditorPanel getEditorPanel()   { return editorPanel;  }
    public ConsolePanel getConsolePanel() { return consolePanel; }
    public StatusBar getStatusBar()       { return statusBar;    }
}
