package com.axiseditor.ui;

import com.axiseditor.utils.UIConstants;

import javax.swing.*;
import java.awt.*;

/**
 * StatusBar — single-line information strip at the bottom of the window.
 *
 * Shows:
 *   • Current file path (or "Untitled")
 *   • Unsaved-changes indicator (" *")
 */
public class StatusBar extends JPanel {

    private final JLabel fileLabel;
    private final JLabel modifiedLabel;

    public StatusBar() {
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(2, 8, 2, 8)
        ));
        setBackground(UIConstants.STATUSBAR_BG);

        fileLabel     = new JLabel("No file open");
        modifiedLabel = new JLabel("");
        fileLabel.setFont(UIConstants.LABEL_FONT);
        modifiedLabel.setFont(UIConstants.LABEL_FONT);
        modifiedLabel.setForeground(new Color(180, 60, 0));  // orange tint for "modified"

        add(fileLabel,     BorderLayout.WEST);
        add(modifiedLabel, BorderLayout.EAST);

        setFilePath(null, false);
    }

    // ── Public API ──────────────────────────────────────────────────────────

    /**
     * Update the status bar.
     *
     * @param path     absolute path of the current file, or null for "Untitled"
     * @param modified true when unsaved changes exist
     */
    public void setFilePath(String path, boolean modified) {
        fileLabel.setText(path != null ? path : "Untitled");
        modifiedLabel.setText(modified ? " ●  Unsaved changes" : "");
    }

    /** Convenience: just flip the modified indicator. */
    public void setModified(boolean modified) {
        modifiedLabel.setText(modified ? " ●  Unsaved changes" : "");
    }

    /** Show a temporary status message (replaces path label for 3 seconds). */
    public void flash(String message) {
        String original = fileLabel.getText();
        fileLabel.setText(message);
        Timer timer = new Timer(3000, e -> fileLabel.setText(original));
        timer.setRepeats(false);
        timer.start();
    }
}
