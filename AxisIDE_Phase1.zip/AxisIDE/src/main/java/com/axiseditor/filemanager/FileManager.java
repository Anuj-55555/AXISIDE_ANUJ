package com.axiseditor.filemanager;

import com.axiseditor.editor.EditorPanel;
import com.axiseditor.ui.ConsolePanel;
import com.axiseditor.ui.StatusBar;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * FileManager — owns all file I/O operations.
 *
 * Responsibilities:
 *   • new file
 *   • open file (with JFileChooser filtered to .sce / .sci)
 *   • save file
 *   • save-as
 *   • prompt the user to save before closing / creating new file
 *   • track current file path and modified state
 *
 * Communicates status back to EditorPanel, StatusBar, and ConsolePanel.
 */
public class FileManager {

    // ── Dependencies ────────────────────────────────────────────────────────
    private final Window parentWindow;
    private EditorPanel  editorPanel;
    private StatusBar    statusBar;
    private ConsolePanel consolePanel;

    // ── State ───────────────────────────────────────────────────────────────
    private File    currentFile;     // null = "Untitled"
    private boolean isModified;      // true when unsaved changes exist

    // ── File filter for JFileChooser ────────────────────────────────────────
    private static final FileNameExtensionFilter SCILAB_FILTER =
            new FileNameExtensionFilter("Scilab Scripts (*.sce, *.sci)", "sce", "sci");

    public FileManager(Window parentWindow) {
        this.parentWindow = parentWindow;
    }

    // ── Dependency injection (set after EditorPanel is created) ─────────────

    public void setEditorPanel(EditorPanel editorPanel) {
        this.editorPanel = editorPanel;
        // Register the "modified" callback
        editorPanel.setOnModifiedCallback(this::markModified);
    }

    public void setStatusBar(StatusBar statusBar) {
        this.statusBar = statusBar;
    }

    public void setConsolePanel(ConsolePanel consolePanel) {
        this.consolePanel = consolePanel;
    }

    // ── Public actions ──────────────────────────────────────────────────────

    /** Create a blank new file (prompts to save first if dirty). */
    public void newFile() {
        promptSaveBeforeAction("New File", () -> {
            editorPanel.setText("");
            currentFile = null;
            isModified  = false;
            updateUI("New untitled file created.\n");
        });
    }

    /** Open an existing Scilab script. */
    public void openFile() {
        promptSaveBeforeAction("Open File", () -> {
            JFileChooser chooser = buildChooser();
            int result = chooser.showOpenDialog(parentWindow);
            if (result != JFileChooser.APPROVE_OPTION) return;

            File selected = chooser.getSelectedFile();
            loadFile(selected);
        });
    }

    /**
     * Open a specific file directly (used by recent-files in Phase 5).
     */
    public void openFile(File file) {
        promptSaveBeforeAction("Open File", () -> loadFile(file));
    }

    /** Save to the current file path, or fall back to Save As. */
    public void saveFile() {
        if (currentFile == null) {
            saveFileAs();
        } else {
            writeToDisk(currentFile);
        }
    }

    /** Always show the save dialog. */
    public void saveFileAs() {
        JFileChooser chooser = buildChooser();
        chooser.setDialogTitle("Save Scilab Script");

        // Suggest the current filename if we have one
        if (currentFile != null) {
            chooser.setSelectedFile(currentFile);
        } else {
            chooser.setSelectedFile(new File("untitled.sce"));
        }

        int result = chooser.showSaveDialog(parentWindow);
        if (result != JFileChooser.APPROVE_OPTION) return;

        File target = chooser.getSelectedFile();
        // Auto-append .sce extension if the user forgot
        if (!target.getName().contains(".")) {
            target = new File(target.getParent(), target.getName() + ".sce");
        }
        writeToDisk(target);
    }

    /**
     * Show a "do you want to save?" dialog if there are unsaved changes,
     * then run the given action.
     *
     * @param actionName human-readable name shown in the dialog title
     * @param action     the operation to run after the save decision
     */
    public void promptSaveBeforeAction(String actionName, Runnable action) {
        if (!isModified) {
            action.run();
            return;
        }

        String filename = currentFile != null ? currentFile.getName() : "Untitled";
        int choice = JOptionPane.showConfirmDialog(
                parentWindow,
                "\"" + filename + "\" has unsaved changes.\nSave before " + actionName + "?",
                "Unsaved Changes",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.WARNING_MESSAGE
        );

        switch (choice) {
            case JOptionPane.YES_OPTION    -> { saveFile(); action.run(); }
            case JOptionPane.NO_OPTION     -> action.run();
            case JOptionPane.CANCEL_OPTION -> { /* abort */ }
        }
    }

    // ── Getters for other components ────────────────────────────────────────

    public File    getCurrentFile() { return currentFile; }
    public boolean isModified()     { return isModified;  }

    // ── Internals ───────────────────────────────────────────────────────────

    /** Read a file from disk and load it into the editor. */
    private void loadFile(File file) {
        if (!file.exists()) {
            JOptionPane.showMessageDialog(parentWindow,
                    "File not found:\n" + file.getAbsolutePath(),
                    "File Not Found", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String content = Files.readString(file.toPath(), StandardCharsets.UTF_8);
            editorPanel.setText(content);
            currentFile = file;
            isModified  = false;
            updateUI("Opened: " + file.getAbsolutePath() + "\n");
        } catch (IOException e) {
            consolePanel.appendError("Could not read file: " + e.getMessage() + "\n");
        }
    }

    /** Write the editor content to disk. */
    private void writeToDisk(File file) {
        try {
            Files.writeString(file.toPath(), editorPanel.getText(), StandardCharsets.UTF_8);
            currentFile = file;
            isModified  = false;
            updateUI("Saved: " + file.getAbsolutePath() + "\n");
        } catch (IOException e) {
            consolePanel.appendError("Could not save file: " + e.getMessage() + "\n");
        }
    }

    /** Called by EditorPanel's document listener on every keystroke. */
    private void markModified() {
        if (!isModified) {
            isModified = true;
            if (statusBar != null) statusBar.setModified(true);
        }
    }

    /** Sync UI components after a file operation. */
    private void updateUI(String consoleMessage) {
        if (statusBar != null) {
            statusBar.setFilePath(
                    currentFile != null ? currentFile.getAbsolutePath() : null,
                    isModified
            );
        }
        if (consolePanel != null) {
            consolePanel.appendMessage(consoleMessage);
        }
    }

    /** Build a consistently configured JFileChooser. */
    private JFileChooser buildChooser() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileFilter(SCILAB_FILTER);
        chooser.setAcceptAllFileFilterUsed(true);
        // Start in the last-used directory if possible
        if (currentFile != null) {
            chooser.setCurrentDirectory(currentFile.getParentFile());
        }
        return chooser;
    }
}
