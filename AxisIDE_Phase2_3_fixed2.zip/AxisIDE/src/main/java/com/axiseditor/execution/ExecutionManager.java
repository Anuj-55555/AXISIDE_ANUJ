package com.axiseditor.execution;

import com.axiseditor.editor.EditorPanel;
import com.axiseditor.filemanager.FileManager;
import com.axiseditor.ui.ConsolePanel;
import com.axiseditor.ui.StatusBar;

import javax.swing.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.List;

/**
 * ExecutionManager — Phase 3 coordinator.
 *
 * Workflow triggered by the Run button:
 *
 *   1. If the current file is unsaved, save it first (temp file if "Untitled").
 *   2. Clear the console.
 *   3. Show "Running…" in status bar.
 *   4. Disable Run button, enable Stop button.
 *   5. Launch ScilabRunner → stream output to ConsolePanel.
 *   6. Collect all stderr.
 *   7. On completion:
 *      a. Append exit code message to console.
 *      b. Parse stderr with ErrorParser.
 *      c. If errors found, highlight the first error line in the editor.
 *      d. Re-enable Run button.
 *
 * This class does NOT touch Swing components from background threads — all
 * UI updates are dispatched via SwingUtilities.invokeLater().
 */
public class ExecutionManager {

    // ── Dependencies ─────────────────────────────────────────────────────────
    private final EditorPanel  editorPanel;
    private final ConsolePanel consolePanel;
    private final FileManager  fileManager;
    private final StatusBar    statusBar;

    private final ScilabRunner runner;

    // ── State ────────────────────────────────────────────────────────────────
    private File        tempFile;       // non-null when we saved an "Untitled" file
    private final StringBuilder stderrAccumulator = new StringBuilder();

    // ── Callbacks for the toolbar (set by MainWindow) ─────────────────────────
    private Runnable onRunStarted;
    private Runnable onRunFinished;

    public ExecutionManager(EditorPanel  editorPanel,
                            ConsolePanel consolePanel,
                            FileManager  fileManager,
                            StatusBar    statusBar) {
        this.editorPanel  = editorPanel;
        this.consolePanel = consolePanel;
        this.fileManager  = fileManager;
        this.statusBar    = statusBar;
        this.runner       = new ScilabRunner();
    }

    // ── Toolbar hooks ─────────────────────────────────────────────────────────

    public void setOnRunStarted(Runnable r)  { this.onRunStarted  = r; }
    public void setOnRunFinished(Runnable r) { this.onRunFinished = r; }

    // ── Run ───────────────────────────────────────────────────────────────────

    public void run() {
        if (runner.isRunning()) {
            consolePanel.appendMessage("[Warning] A script is already running. Stop it first.\n");
            return;
        }

        // ── Step 1: resolve file to execute ──────────────────────────────
        String scriptPath = resolveScriptPath();
        if (scriptPath == null) return;   // user cancelled

        // ── Step 2-4: prepare UI ─────────────────────────────────────────
        consolePanel.clear();
        consolePanel.appendMessage("▶  Running: " + scriptPath + "\n");
        consolePanel.appendMessage("─".repeat(50) + "\n");
        statusBar.flash("Running script…");
        if (onRunStarted != null) SwingUtilities.invokeLater(onRunStarted);

        stderrAccumulator.setLength(0);  // reset error buffer

        // ── Step 5: execute ───────────────────────────────────────────────
        runner
            .onOutput(line -> SwingUtilities.invokeLater(() ->
                    consolePanel.appendMessage(line)))
            .onError(line -> {
                SwingUtilities.invokeLater(() ->
                        consolePanel.appendError(line));
                stderrAccumulator.append(line);
            })
            .onDone(exitCode -> SwingUtilities.invokeLater(() ->
                    handleDone(exitCode)))
            .run(scriptPath);
    }

    /** Stop a running script. */
    public void stop() {
        runner.stop();
        consolePanel.appendMessage("\n[Execution stopped by user.]\n");
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    /**
     * Returns the path of the script to run.
     * Saves the current editor content if needed.
     * Returns null if the user cancels.
     */
    private String resolveScriptPath() {
        File currentFile = fileManager.getCurrentFile();

        if (currentFile != null) {
            // Auto-save before running
            if (fileManager.isModified()) {
                fileManager.saveFile();
            }
            return currentFile.getAbsolutePath();
        }

        // "Untitled" — save to a temp file
        try {
            tempFile = File.createTempFile("axis_run_", ".sce");
            tempFile.deleteOnExit();
            Files.writeString(tempFile.toPath(),
                    editorPanel.getText(), StandardCharsets.UTF_8);
            return tempFile.getAbsolutePath();
        } catch (IOException e) {
            consolePanel.appendError("Could not create temp file: " + e.getMessage() + "\n");
            return null;
        }
    }

    /** Called on the EDT when the process exits. */
    private void handleDone(int exitCode) {
        // ── Separator and exit info ───────────────────────────────────────
        consolePanel.appendMessage("─".repeat(50) + "\n");
        if (exitCode == 0) {
            consolePanel.appendMessage("✔  Process exited successfully (code 0)\n");
        } else if (exitCode == -1) {
            consolePanel.appendMessage("⚠  Scilab not found. Check SCILAB_HOME.\n");
        } else {
            consolePanel.appendMessage("✘  Process exited with code " + exitCode + "\n");
        }

        // ── Error parsing & line highlighting ─────────────────────────────
        String stderr = stderrAccumulator.toString();
        if (!stderr.isBlank()) {
            List<ErrorParser.ParsedError> errors = ErrorParser.parse(stderr);
            for (ErrorParser.ParsedError err : errors) {
                if (err.lineNumber > 0) {
                    consolePanel.appendMessage("[Error at line " + err.lineNumber + "] " + err.message + "\n");
                    editorPanel.highlightErrorLine(err.lineNumber);
                    break;  // highlight the first error only
                }
            }
        }

        // ── Restore UI ────────────────────────────────────────────────────
        if (onRunFinished != null) onRunFinished.run();
        statusBar.flash(exitCode == 0 ? "Execution complete." : "Execution failed.");

        // Clean up temp file if we created one
        if (tempFile != null) {
            tempFile.delete();
            tempFile = null;
        }
    }
}
