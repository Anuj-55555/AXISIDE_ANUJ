package com.axiseditor.ui;

import com.axiseditor.editor.EditorPanel;
import com.axiseditor.filemanager.FileManager;
import com.axiseditor.utils.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * ToolbarPanel — horizontal strip of action buttons.
 *
 * Phase 1 buttons: New · Open · Save · Save As
 * Phase 3 adds:    ▶ Run  · ■ Stop
 */
public class ToolbarPanel extends JPanel {

    private final FileManager   fileManager;
    private final EditorPanel   editorPanel;
    private final ConsolePanel  consolePanel;

    private JButton btnNew;
    private JButton btnOpen;
    private JButton btnSave;
    private JButton btnSaveAs;
    private JButton btnRun;
    private JButton btnStop;

    public ToolbarPanel(FileManager fileManager,
                        EditorPanel editorPanel,
                        ConsolePanel consolePanel) {
        this.fileManager  = fileManager;
        this.editorPanel  = editorPanel;
        this.consolePanel = consolePanel;
        initUI();
    }

    private void initUI() {
        setLayout(new FlowLayout(FlowLayout.LEFT, 4, 4));
        setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(60, 60, 60)));
        setBackground(UIConstants.TOOLBAR_BG);

        btnNew    = createButton("New",     "Create a new Scilab script",    e -> fileManager.newFile());
        btnOpen   = createButton("Open",    "Open an existing Scilab file",  e -> fileManager.openFile());
        btnSave   = createButton("Save",    "Save the current file",         e -> fileManager.saveFile());
        btnSaveAs = createButton("Save As", "Save the file under a new name",e -> fileManager.saveFileAs());

        // Phase 3 run/stop — greyed out until ExecutionManager is wired
        btnRun  = createButton("▶  Run",  "Run the current script (Ctrl+R)",  null);
        btnStop = createButton("■  Stop", "Stop the running script",           null);
        btnRun.setEnabled(false);
        btnStop.setEnabled(false);
        btnRun.setForeground(new Color(100, 180, 100));
        btnStop.setForeground(new Color(200, 80, 80));

        add(btnNew);
        add(btnOpen);
        add(btnSave);
        add(btnSaveAs);
        addSeparator();
        add(btnRun);
        add(btnStop);
    }

    // ── Phase 3 wiring ────────────────────────────────────────────────────────

    /**
     * Called by MainWindow after ExecutionManager is created.
     * Enables Run/Stop and attaches actions.
     */
    public void wireExecutionActions(ActionListener runAction, ActionListener stopAction) {
        btnRun.addActionListener(runAction);
        btnStop.addActionListener(stopAction);
        btnRun.setEnabled(true);
    }

    /** Called by ExecutionManager.onRunStarted — disable Run, enable Stop. */
    public void setRunning(boolean running) {
        btnRun.setEnabled(!running);
        btnStop.setEnabled(running);
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void addSeparator() {
        JSeparator sep = new JSeparator(JSeparator.VERTICAL);
        sep.setPreferredSize(new Dimension(6, 24));
        add(sep);
    }

    private JButton createButton(String text, String tooltip, ActionListener action) {
        JButton btn = new JButton(text);
        btn.setToolTipText(tooltip);
        btn.setFocusPainted(false);
        btn.setFont(UIConstants.BUTTON_FONT);
        if (action != null) btn.addActionListener(action);
        return btn;
    }
}
