package com.axiseditor.ui;

import com.axiseditor.editor.EditorPanel;
import com.axiseditor.execution.ExecutionManager;
import com.axiseditor.filemanager.FileManager;
import com.axiseditor.utils.UIConstants;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * MainWindow — root JFrame of the Axis IDE (Phase 1–3).
 *
 * Layout:
 *   ┌─────────────────────────────────┐
 *   │  Toolbar                        │
 *   ├─────────────────────┬───────────┤
 *   │  Editor Panel       │  Console  │
 *   ├─────────────────────┴───────────┤
 *   │  Status Bar                     │
 *   └─────────────────────────────────┘
 *
 * Phase 3 additions:
 *   • ExecutionManager created and wired.
 *   • Run / Stop toolbar buttons activated.
 *   • Ctrl+R keyboard shortcut for Run.
 */
public class MainWindow extends JFrame {

    private EditorPanel      editorPanel;
    private ConsolePanel     consolePanel;
    private ToolbarPanel     toolbarPanel;
    private StatusBar        statusBar;
    private FileManager      fileManager;
    private ExecutionManager executionManager;

    public MainWindow() {
        super(UIConstants.APP_TITLE);
        initComponents();
        setupLayout();
        setupWindowBehaviour();
        setupGlobalShortcuts();
    }

    private void initComponents() {
        fileManager      = new FileManager(this);
        editorPanel      = new EditorPanel();
        consolePanel     = new ConsolePanel();
        statusBar        = new StatusBar();
        toolbarPanel     = new ToolbarPanel(fileManager, editorPanel, consolePanel);

        fileManager.setEditorPanel(editorPanel);
        fileManager.setStatusBar(statusBar);
        fileManager.setConsolePanel(consolePanel);

        // ── Phase 3: wire ExecutionManager ───────────────────────────────
        executionManager = new ExecutionManager(editorPanel, consolePanel, fileManager, statusBar);

        executionManager.setOnRunStarted(()  -> toolbarPanel.setRunning(true));
        executionManager.setOnRunFinished(() -> toolbarPanel.setRunning(false));

        toolbarPanel.wireExecutionActions(
                e -> executionManager.run(),
                e -> executionManager.stop()
        );
    }

    private void setupLayout() {
        setLayout(new BorderLayout());
        add(toolbarPanel, BorderLayout.NORTH);

        JSplitPane splitPane = new JSplitPane(
                JSplitPane.HORIZONTAL_SPLIT, editorPanel, consolePanel);
        splitPane.setResizeWeight(0.75);
        splitPane.setDividerSize(5);
        splitPane.setContinuousLayout(true);
        add(splitPane, BorderLayout.CENTER);

        add(statusBar, BorderLayout.SOUTH);

        setSize(UIConstants.DEFAULT_WIDTH, UIConstants.DEFAULT_HEIGHT);
        setMinimumSize(new Dimension(800, 500));
        setLocationRelativeTo(null);
    }

    private void setupWindowBehaviour() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (executionManager != null) executionManager.stop();
                fileManager.promptSaveBeforeAction("Exit", MainWindow.this::dispose);
            }
        });
    }

    /** Register app-wide shortcuts (not tied to a specific component). */
    private void setupGlobalShortcuts() {
        // Ctrl+R → Run
        KeyStroke runKey = KeyStroke.getKeyStroke(KeyEvent.VK_R, InputEvent.CTRL_DOWN_MASK);
        getRootPane().registerKeyboardAction(
                e -> executionManager.run(),
                runKey,
                JComponent.WHEN_IN_FOCUSED_WINDOW
        );
    }

    // ── Accessors ─────────────────────────────────────────────────────────────
    public EditorPanel      getEditorPanel()      { return editorPanel;      }
    public ConsolePanel     getConsolePanel()      { return consolePanel;     }
    public StatusBar        getStatusBar()         { return statusBar;        }
    public ExecutionManager getExecutionManager()  { return executionManager; }
}
