package com.axiseditor.editor;

import com.axiseditor.editor.scilab.*;
import com.axiseditor.utils.UIConstants;
import org.fife.ui.autocomplete.AutoCompletion;
import org.fife.ui.rsyntaxtextarea.*;
import org.fife.ui.rtextarea.*;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.*;

/**
 * EditorPanel — Phase 2 upgrade.
 *
 * New in Phase 2:
 *   • Scilab syntax highlighting via ScilabTokenMaker
 *   • VS Code dark theme (ScilabTheme)
 *   • Rainbow bracket / quote colorising (BracketColorizer)
 *   • Smart template insertion on Enter (ScilabTemplateEngine)
 *   • Smart typing: wrap-selection, auto-close pairs (SmartTypingHandler)
 *   • Ctrl+/ line / multi-line comment toggle
 *   • Keyword + variable auto-completion (ScilabAutoComplete)
 *   • Find / Replace dialog (Ctrl+F / Ctrl+H)
 *   • Undo / Redo via Ctrl+Z / Ctrl+Y (RSyntaxTextArea built-in)
 *   • Tabbed editing support stubs (Phase 2 single-tab; Phase 5 multi-tab)
 */
public class EditorPanel extends JPanel {

    private final RSyntaxTextArea textArea;
    private final RTextScrollPane scrollPane;
    private FindReplaceDialog     findReplaceDialog;   // lazy-created, kept alive

    /** Fired whenever the document changes (used by FileManager). */
    private Runnable onModifiedCallback;

    public EditorPanel() {
        setLayout(new BorderLayout());

        // ── Register our custom Scilab syntax factory ────────────────────
        ScilabTokenMakerFactory factory = new ScilabTokenMakerFactory();
        AbstractTokenMakerFactory.setDefaultInstance(factory);

        textArea   = buildTextArea();
        scrollPane = new RTextScrollPane(textArea);
        scrollPane.setLineNumbersEnabled(true);

        // Style the line-number gutter to match the dark theme
        Gutter gutter = scrollPane.getGutter();
        gutter.setBackground(ScilabTheme.LINE_NUMBER_BG);
        gutter.setLineNumberColor(ScilabTheme.LINE_NUMBER_FG);

        TitledBorder border = BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(70, 70, 70)),
                "Editor",
                TitledBorder.LEFT,
                TitledBorder.TOP,
                UIConstants.LABEL_FONT
        );
        border.setTitleColor(Color.LIGHT_GRAY);
        setBorder(border);
        add(scrollPane, BorderLayout.CENTER);

        // ── Install Phase 2 features ─────────────────────────────────────
        new BracketColorizer(textArea);                  // rainbow brackets
        SmartTypingHandler.install(textArea);            // wrap/auto-close/Ctrl+/
        ScilabAutoComplete.install(textArea);            // autocomplete popup
        installTemplateEnterBinding();                   // template on Enter
        installKeyboardShortcuts();                      // Ctrl+F / Ctrl+H / Ctrl+Z / Ctrl+Y

        // ── Notify FileManager on every change ───────────────────────────
        textArea.getDocument().addDocumentListener(new DocumentListener() {
            @Override public void insertUpdate(DocumentEvent e)  { notifyModified(); }
            @Override public void removeUpdate(DocumentEvent e)  { notifyModified(); }
            @Override public void changedUpdate(DocumentEvent e) { notifyModified(); }
        });
    }

    // ── Builder ───────────────────────────────────────────────────────────────

    private RSyntaxTextArea buildTextArea() {
        RSyntaxTextArea ta = new RSyntaxTextArea();

        // ── Scilab syntax highlighting ────────────────────────────────────
        ta.setSyntaxEditingStyle(ScilabTokenMakerFactory.SYNTAX_STYLE_SCILAB);
        ScilabTheme.apply(ta);                           // dark theme + token colours

        // ── Editor behaviour ──────────────────────────────────────────────
        ta.setFont(UIConstants.EDITOR_FONT);
        ta.setTabSize(4);
        ta.setAutoIndentEnabled(true);
        ta.setAntiAliasingEnabled(true);
        ta.setCodeFoldingEnabled(false);
        ta.setHighlightCurrentLine(true);

        // ── Bracket matching ──────────────────────────────────────────────
        ta.setBracketMatchingEnabled(true);
        ta.setAnimateBracketMatching(false);
        ta.setMatchedBracketBGColor(ScilabTheme.BRACKET_MATCH_BG);
        ta.setMatchedBracketBorderColor(ScilabTheme.BRACKET_MATCH_BORDER);

        ta.setMargin(new Insets(4, 6, 4, 6));
        return ta;
    }

    // ── Keyboard bindings ─────────────────────────────────────────────────────

    /**
     * Override the Enter key: if ScilabTemplateEngine handles it (keyword
     * on line), consume the event; otherwise fall through to default newline.
     */
    private void installTemplateEnterBinding() {
        KeyStroke enter = KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0);
        textArea.getInputMap().put(enter, "axis-enter");
        textArea.getActionMap().put("axis-enter", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) {
                if (!ScilabTemplateEngine.handleEnter(textArea)) {
                    // Let the default action handle a plain newline
                    textArea.getActionMap().get("insert-break").actionPerformed(e);
                }
            }
        });
    }

    private void installKeyboardShortcuts() {
        // Ctrl+F → Find
        textArea.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_F, InputEvent.CTRL_DOWN_MASK), "axis-find");
        textArea.getActionMap().put("axis-find", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { openFindReplace(false); }
        });

        // Ctrl+H → Find & Replace
        textArea.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_H, InputEvent.CTRL_DOWN_MASK), "axis-replace");
        textArea.getActionMap().put("axis-replace", new AbstractAction() {
            @Override public void actionPerformed(ActionEvent e) { openFindReplace(true); }
        });

        // Ctrl+Z and Ctrl+Y are handled natively by RSyntaxTextArea (UndoManager).
        // Ctrl+/ is handled by SmartTypingHandler.
    }

    // ── Find/Replace ──────────────────────────────────────────────────────────

    private void openFindReplace(boolean focusReplace) {
        Frame owner = (Frame) SwingUtilities.getWindowAncestor(this);
        if (findReplaceDialog == null) {
            findReplaceDialog = new FindReplaceDialog(owner, textArea);
        }
        findReplaceDialog.prefillWithSelection();
        findReplaceDialog.setVisible(true);
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /** Replace the entire editor content (called on file open). */
    public void setText(String content) {
        textArea.setText(content);
        textArea.setCaretPosition(0);
        textArea.discardAllEdits();          // clear undo history for fresh file
    }

    /** Get the current editor content. */
    public String getText() {
        return textArea.getText();
    }

    /** Check whether the text area is empty. */
    public boolean isEmpty() {
        return textArea.getText().trim().isEmpty();
    }

    /**
     * Register a callback fired on every keystroke / document change.
     * FileManager uses this to track the "modified" state.
     */
    public void setOnModifiedCallback(Runnable callback) {
        this.onModifiedCallback = callback;
    }

    /** Expose the underlying RSyntaxTextArea for Phase 3/4 configuration. */
    public RSyntaxTextArea getTextArea() {
        return textArea;
    }

    /** Highlight a specific line number (1-based). Used by Phase 4 error highlighting. */
    public void highlightErrorLine(int lineNumber) {
        try {
            if (lineNumber < 1) return;
            int offset = textArea.getLineStartOffset(lineNumber - 1);
            textArea.setCaretPosition(offset);
            textArea.requestFocusInWindow();
        } catch (Exception ignored) { }
    }

    // ── Internals ─────────────────────────────────────────────────────────────

    private void notifyModified() {
        if (onModifiedCallback != null) {
            onModifiedCallback.run();
        }
    }
}
